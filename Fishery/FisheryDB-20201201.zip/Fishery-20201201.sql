-- --------------------------------------------------------
-- 主機:                           127.0.0.1
-- 伺服器版本:                        10.5.4-MariaDB - mariadb.org binary distribution
-- 伺服器作業系統:                      Win64
-- HeidiSQL 版本:                  11.0.0.5919
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- 傾印 fishery 的資料庫結構
CREATE DATABASE IF NOT EXISTS `fishery` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `fishery`;

-- 傾印  資料表 fishery.boat 結構
CREATE TABLE IF NOT EXISTS `boat` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(50) NOT NULL,
  `boat_name` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `licence_expired` varchar(50) NOT NULL,
  `belong` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8;

-- 正在傾印表格  fishery.boat 的資料：~44 rows (近似值)
/*!40000 ALTER TABLE `boat` DISABLE KEYS */;
INSERT INTO `boat` (`id`, `code`, `boat_name`, `name`, `phone`, `licence_expired`, `belong`) VALUES
	(1, 'CT1-8139', '捷龍', '王奇文', '0928-949381', '1100414', '深澳'),
	(2, 'CT2-5251', '文翔', '袁文成', '0919-716556', '1090317', '深澳'),
	(3, 'CT2-5257', '協興26', '簡金榮', '0911-226680 0911-259680', '1090624', '深澳'),
	(4, 'CT2-5874', '新協大16', '簡志興', '0910-953954 0935-307654', '1091011', '深澳'),
	(5, 'CT2-5918', '嵐海秘境8', '王曦筠', '093-3095157', '1100425', '深澳'),
	(6, 'CT2-5925', '海之星', '曾冠華', '0988-122407 2462-0119', '1090621', '深澳'),
	(7, 'CT2-5993', '航海家', '蔡志謙', '0932-081348', '1090906', '深澳'),
	(8, 'CT2-5996', '全美168', '凌文政', '0976-769512', '1091204', '深澳'),
	(9, 'CT2-5999', '穩勝66', '郭武平', '0910-336125', '1090620', '深澳'),
	(10, 'CT2-6012', '旭陽', '王憲國', '0966-687559', '1100422', '深澳'),
	(11, 'CT2-6021', '亞太888', '林志明', '0906-879143 03-978-0538', '1090602', '深澳'),
	(12, 'CT2-6444', '東大8', '葉仕文', '0915-888221 0912-299236', '1090623', '深澳'),
	(13, 'CT2-6449', '串串9527', '曾勤傑', '0985-171080 0921-635191', '1090527', '深澳'),
	(14, 'CT2-6450', '筌富1', '古富元', '0936-272642', '1090824', '深澳'),
	(15, 'CT2-6468', '一拳', '王嘉樑', '0916-117797', '1091230', '深澳'),
	(16, 'CT2-6952', '東大', '洪崇恩', '0905-723158 0919-336450', '1100201', '深澳'),
	(17, 'CT2-6975', '萬豪', '黃友信', '0988-873889 0937-856236', '1090723', '深澳'),
	(18, 'CT2-7027', '上達', '陳汶愉', '0939-227440 0924-095876', '1090830', '深澳'),
	(19, 'CT2-7029', '永益2', '賴慶昌', '0937-278198', '1100319', '深澳'),
	(20, 'CT2-7035', '無限', '郭金富', '0920-767707', '1090625', '深澳'),
	(21, 'CT2-7038', '赤馬888', '許志宏', '0911-785500 0978-882573', '1090507', '深澳'),
	(22, 'CT2-7041', '藍天168', '藍天生', '0939-767636子 03-9386333', '1090605', '深澳'),
	(23, 'CT2-7064', '東區168', '郭裕明', '0933-16845 0930-611900', '1100114', '深澳'),
	(24, 'CT2-7081', '泰順2', '葉耀輝', '0937-031976', '1091204', '深澳'),
	(25, 'CT3-5680', '全家福6', '游明川', '0935-860066', '1100224', '深澳'),
	(26, 'CT3-5721', '鴻達興6', '杜坤達', '02-24977235 0937-428407', '1090711', '深澳'),
	(27, 'CT3-5724', '航海家16', '周麗錦', '02-24691948 0932-074815', '1090724', '深澳'),
	(28, 'CT3-5821', '海星', '洪永豪', '0939-618862 0920-875575太太', '1090731', '深澳'),
	(29, 'CT3-35833', '三三', '張建清', '928238204', '1100621', '深澳'),
	(30, 'CT3-5970', '航海家33', '廖明祥', '0919-982156', '1090526', '深澳'),
	(31, 'CT3-6025', '廣禾登8', '林紫誼', '0955-885087', '1090712', '深澳'),
	(32, 'CT3-6069', '七海6', '陳琬渝', '0937-081895', '1100116', '深澳'),
	(33, 'CT3-6077', '名人999', '范建智', '955724920', '1090623', '深澳'),
	(34, 'CT3-6081', '航海家18', '周麗錦', '932074815', '1090828', '深澳'),
	(35, 'CT3-6085', '陽明166', '曾淑貞', '919393963', '1090803', '深澳'),
	(36, 'CT3-6102', '昇陽168', '黃遠淩', '980111579', '1090707', '深澳'),
	(37, 'CT3-6110', '大統6', '王國智', '0937-053086', '1090523', '深澳'),
	(38, 'CT3-6118', '陽明168', '陳義雄', '0919-393963', '1100106', '深澳'),
	(39, 'CT3-6122', '大統1', '許燕雯', '0937-053086 0970-380406', '1090612', '深澳'),
	(40, 'CT3-6172', '全家福166', '王宏丞', '0930-558306 0935-860066', '1100319', '深澳'),
	(41, 'CT3-6176', '大武2', '鄭劍虹', '0935-899781 0925-899781', '1090813', '深澳'),
	(42, 'CT3-6177', '維多利亞', '黃岩松', '0910-014988', '1090830', '深澳'),
	(43, 'CT3-6227', '全家福128', '王麗惠', '0935-860066', '1090717', '深澳'),
	(44, 'CT3-6290', '海星169', '張文聰', '0920-875575太太0939-618862', '1100304', '深澳');
/*!40000 ALTER TABLE `boat` ENABLE KEYS */;

-- 傾印  資料表 fishery.carousel 結構
CREATE TABLE IF NOT EXISTS `carousel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` enum('pic','video') NOT NULL DEFAULT 'pic',
  `src` varchar(512) NOT NULL DEFAULT '',
  `alt` varchar(512) NOT NULL DEFAULT '',
  `seq` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- 正在傾印表格  fishery.carousel 的資料：~2 rows (近似值)
/*!40000 ALTER TABLE `carousel` DISABLE KEYS */;
INSERT INTO `carousel` (`id`, `type`, `src`, `alt`, `seq`) VALUES
	(1, 'pic', 'loop_1.jpg', 'Loop1', 1),
	(3, 'pic', 'exercise-taipei.png', '110年全國運動會在新北', 0);
/*!40000 ALTER TABLE `carousel` ENABLE KEYS */;

-- 傾印  資料表 fishery.food 結構
CREATE TABLE IF NOT EXISTS `food` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `cover` varchar(100) NOT NULL,
  `desc` varchar(100) DEFAULT '',
  `pic1` varchar(100) DEFAULT NULL,
  `pic2` varchar(100) DEFAULT NULL,
  `pic3` varchar(100) DEFAULT NULL,
  `open_time` varchar(100) DEFAULT NULL,
  `update_time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `seq` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- 正在傾印表格  fishery.food 的資料：~7 rows (近似值)
/*!40000 ALTER TABLE `food` DISABLE KEYS */;
INSERT INTO `food` (`id`, `name`, `cover`, `desc`, `pic1`, `pic2`, `pic3`, `open_time`, `update_time`, `seq`) VALUES
	(1, '老船長平價海鮮', 'm_01.jpg', '', NULL, NULL, NULL, NULL, '2020-09-02 06:18:13', 0),
	(2, '長榮小吃', 'm_02.jpg', '', NULL, NULL, NULL, NULL, '2020-09-02 06:18:27', 0),
	(3, '紅梅小吃', 'm_03.jpg', '', NULL, NULL, NULL, NULL, '2020-09-02 06:18:32', 0),
	(4, '阿華鯊魚羹', 'm_04.jpg', '', NULL, NULL, NULL, NULL, '2020-09-02 06:18:37', 0),
	(5, '金益鯊魚羹', 'm_05.jpg', '', NULL, NULL, NULL, NULL, '2020-09-02 06:18:42', 0),
	(6, '天福宮志工媽媽', 'm_06.jpg', '', NULL, NULL, NULL, NULL, '2020-09-02 06:18:47', 0),
	(7, '深澳港海鮮樓', 'm_07.jpg', '', NULL, NULL, NULL, NULL, '2020-09-02 06:18:51', 0);
/*!40000 ALTER TABLE `food` ENABLE KEYS */;

-- 傾印  資料表 fishery.food_menu 結構
CREATE TABLE IF NOT EXISTS `food_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `food_id` int(11) NOT NULL DEFAULT 0,
  `name` varchar(100) NOT NULL DEFAULT '',
  `pic1` varchar(100) DEFAULT NULL,
  `pic2` varchar(100) DEFAULT NULL,
  `pic3` varchar(100) DEFAULT NULL,
  `desc` text NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `FK_food_menu_food` (`food_id`),
  CONSTRAINT `FK_food_menu_food` FOREIGN KEY (`food_id`) REFERENCES `food` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

-- 正在傾印表格  fishery.food_menu 的資料：~14 rows (近似值)
/*!40000 ALTER TABLE `food_menu` DISABLE KEYS */;
INSERT INTO `food_menu` (`id`, `food_id`, `name`, `pic1`, `pic2`, `pic3`, `desc`) VALUES
	(1, 1, '老船長墨魚香腸', 'm_9.jpg', '', '', '端上低調的菜色，看似不出眾，但那可是船長嚴選噴汁墨魚香腸，渾厚飽滿的香腸裡、熱情的注入滿滿墨魚汁及墨魚丁，無論是大口咬還是小口咬，每一口都充斥著墨魚香、海洋鮮甜風味，絕對是全家大小的『秒殺菜』。'),
	(2, 1, '老船長透抽米粉', 'm_10.jpg', '', '', '一上桌，立馬感受到氣勢滂礡的震撼感，數不盡的滿滿透抽加上吸滿鮮甜精華的米粉，最後撒上古早油蔥酥、細切芹菜末，這時才知道原來米粉也是透抽的好麻吉，不愧是店內必點招牌，保證讓你滿載而歸！'),
	(3, 2, '長榮小吃 酥炸白帶魚', 'm_3.jpg', NULL, NULL, '噓...這是老闆的秘密請勿透露，他讓新鮮的白帶魚彈跳耀下油鍋，採用高溫油炸方式鎖住白帶魚鮮嫩多汁的肉質，鮮甜不流失，告別了以往白帶魚乾煎死鹹的印象，總是讓人忍不住驚呼：蛤？怎麼可以這麼鮮嫩好入口。'),
	(4, 2, '長榮小吃 蒜香小卷', 'm_4.jpg', NULL, NULL, '這個下酒開胃菜，只能說很下飯！大蒜下入油鍋爆香，此時香氣逼出讓你的唾液腺急速分泌，加上與小卷的鮮甜海味相互呼應，讓你的味覺感受更上一層，此時一定要來一杯啤酒與炎炎夏日，更是一絕！'),
	(5, 3, '紅梅小吃花枝羹湯', 'm_5.jpg', NULL, NULL, '現撈Q彈花枝加上翠綠蔬菜一同熬煮，用料大方不吝嗇，原汁原味的展現在地活力熱情滋味，運用了食材本身的鮮美，讓你每口都鮮甜、每口都滿足，就是要讓你意猶未盡！'),
	(6, 3, '紅梅小吃小卷米粉', 'm_6.jpg', NULL, NULL, '就地取材深澳當地的極鮮小卷，鎖住了大海的鮮甜，並完整釋放在你面前，小卷口感鮮嫩Q彈，並搭配吸滿海味的米粉，清爽不負擔，是你必吃的台灣港邊道地小吃。'),
	(7, 4, '阿華鯊魚羹川燙小卷', 'm_1.jpg', NULL, NULL, '天然誒～尚青，採用川燙更能忠實呈現小卷的鮮甜及海味，肉質Q彈活力又多汁，輕鬆喚醒你的每一寸細胞。最簡單的料理，帶出食材本身最自然的滋味，這才是海鮮饕客最愛的『原味主義』。'),
	(8, 4, '阿華鯊魚羹-鯊魚羹湯', 'm_2.jpg', NULL, NULL, '豪邁的現流鯊魚，是你朝聖必敗的美味，魚肉口感軟嫩鮮甜，裹粉的Q彈鯊魚外皮，湯頭不過份的勾芡，只恰到好處的鉤住你的胃，高貴不貴的平民料理，建議您，想吃的可要早一點來！'),
	(9, 5, '金益糖醋鰻魚', 'm_7.jpg', NULL, NULL, '就是它！總是擄獲眾人的口味！金黃酥炸鰻魚一端上桌，一咬下去就感受到鰻魚的鮮美彈性，並搭配上糖醋勾芡醬汁，這酸酸甜甜的開胃香氣，誰還敢說今天沒胃口？白飯絕對不只一碗。'),
	(10, 5, '金益鯊魚羹', 'm_8.jpg', NULL, NULL, '自家漁船捕魚，新鮮不用老闆說！裹上現炸脆皮的鯊魚肉，外脆內軟的快感，無違和的融進濃心羹湯裡，撒上些許油蔥及香菜作調料，吃得出滋味而不搶風頭，讓平易近人的羹湯，成為在地人口耳相傳的好味道。'),
	(11, 6, '天福宮志工媽媽古早味手工雞捲', 'm_13.jpg', NULL, NULL, '酥炸剛起鍋的金黃色誘人外皮，捲入你心的豐富內餡，伴隨著香噴熱氣襲捲而上，總是讓人情不自禁的勾起一幕幕溫馨回憶，在這裡獻上手工經典滋味，讓你追回家鄉味。'),
	(12, 6, '天福宮志工媽媽古早味油飯', 'm_14.jpg', NULL, NULL, '吃膩了白米飯？這時候就該來個香蒸糯米嚼勁口感，巧妙的將炒香的香菇、蝦米、肉絲黏合了在一起，時光暫停......突然回想起原來這就是傳統樸實的好味道，美味程度讓人無法拒絕。'),
	(13, 7, '白帶魚金針湯', 'm_11.jpg', NULL, NULL, '誰說白帶魚只能乾煎或油炸？我就是要來點不一樣的！富含鮮嫩肉質的白帶魚搭上金針花淡雅清新的爽脆口感，湯汁鮮甜清香，如果您愛好健康主義的話，一定要來試試這個巧妙的山海組合。'),
	(14, 7, '小卷白帶魚蘿蔔糕', 'm_12.jpg', NULL, NULL, '蘿蔔糕加蛋膩了嗎？私心推薦你絕對沒嘗過的意外組合！小卷、白帶魚、蘿蔔糕三重奏，乍看之下很違和，親嚐之後即刻上癮，讓你的視覺、嗅覺、味覺全部大躍進！');
/*!40000 ALTER TABLE `food_menu` ENABLE KEYS */;

-- 傾印  資料表 fishery.marquee 結構
CREATE TABLE IF NOT EXISTS `marquee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `text` varchar(512) NOT NULL DEFAULT '',
  `seq` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- 正在傾印表格  fishery.marquee 的資料：~0 rows (近似值)
/*!40000 ALTER TABLE `marquee` DISABLE KEYS */;
INSERT INTO `marquee` (`id`, `text`, `seq`) VALUES
	(1, '110年全國運動會在新北', 0);
/*!40000 ALTER TABLE `marquee` ENABLE KEYS */;

-- 傾印  資料表 fishery.scenic_spot 結構
CREATE TABLE IF NOT EXISTS `scenic_spot` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL DEFAULT '0',
  `cover` varchar(100) NOT NULL DEFAULT '0',
  `desc` text NOT NULL DEFAULT '0',
  `pic1` varchar(100) DEFAULT NULL,
  `pic2` varchar(100) DEFAULT NULL,
  `pic3` varchar(100) DEFAULT NULL,
  `update_time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `seq` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COMMENT='景點介紹';

-- 正在傾印表格  fishery.scenic_spot 的資料：~6 rows (近似值)
/*!40000 ALTER TABLE `scenic_spot` DISABLE KEYS */;
INSERT INTO `scenic_spot` (`id`, `name`, `cover`, `desc`, `pic1`, `pic2`, `pic3`, `update_time`, `seq`) VALUES
	(1, '象鼻岩', 'j_01.png', '象鼻岩為網路廣為流傳的台灣36個秘境之一，<br>顧名思義為外觀酷似一頭巨象側身矗立於海上之巨岩，<br>懸崖岬角為象身，<br>海蝕拱門細長彎曲的石塊則宛如巨象的長鼻伸向深不見底的大海，<br>象頭與象鼻之間的空隙形成海蝕洞的拱門景觀。<br>如果從更高處來欣賞這象鼻海蝕洞，<br>可已將整個岬角的岩塊盡收眼底，<br>搭配懸崖下深藍色的大海托起岬角巨岩，<br>不得不讚嘆大自然的鬼斧神工。', 'P1011567.jpg', 'P1011580.jpg', 'P1011591.jpg', '2020-07-19 15:28:17', 0),
	(2, '酋長岩', 'j_02.png', '經深澳漁港，不遠處可望見酋長岩，<br>此深澳岬角的巨岩壁，從側面看，<br>輪廓神似印地安人酋長臉龐，<br>故本地名舊稱為「番仔澳」。<br>要欣賞酋長岩的最佳角度不是在岩石附近，<br>而且一進漁港沒多久的景觀平台，<br>從這邊可以清楚的看見酋長茂密的頭髮，<br>還有臉上的輪廓。', 'P1011532.jpg', 'P1011538.jpg', 'P1011541.jpg', '2020-07-21 00:10:11', 0),
	(3, '海天步道', 'j_03.png', '沿著深澳漁港邊建造310公尺的觀景平台，<br>擁有270度的遼闊觀海視野，可遠眺九份山城美景，<br>欣賞傳統漁業點點燈火，跟可愛活潑的小捲裝置藝術拍照，<br>盡頭魚骨造型的造景在碧海藍天下特別耀眼，<br>海天一線成為深澳的私房景點。<br>到了晚上，步道則化身為美麗光雕，豐富的色彩形成光浪，<br>與漁火交織、黃金山城相輝映，星光熠熠越夜越浪漫，<br>讓人忘記城市的喧囂，下次品嚐完在地美味海鮮後，<br>不妨來深澳漁港海天步道走走吧！', 'P1011632.jpg', 'P1011641.jpg', 'P1011653.jpg', '2020-07-21 00:10:14', 0),
	(4, '水湳洞漁港', 'j_04.png', '水湳洞漁港位於台2線濱海公路旁，<br>與對面的十三層遺址及長仁社區遙遙相對。<br>在濱海公路要轉彎前往金瓜石黃金博物園區的這個路口，<br>也就是在水湳洞停車場附近，<br>有一條在濱海公路旁的小路往下就可以到達水湳洞漁港，<br>不過入口處有設立一標語，禁止一般遊客進入此港區，<br>目前此漁港內有哨站並且有軍警駐防在此漁港。<br>如果由遊客進入了水湳洞漁港區域，<br>會有軍警前來關切為何要在於漁港停留，<br>不過只要遊客表明身份及目的，並且不要停留太久，<br>軍警人員都會非常客氣地讓您參觀此漁港。', 'P1011699.jpg', 'P1011702.jpg', 'P1011729.jpg', '2020-07-21 00:10:05', 0),
	(5, '深澳鐵道自行車', 'j_05.png', '鐵軌自行車八斗子段緊鄰著八斗子火車站，<br>八斗子火車站除了是全台離海邊最近的火車站外，<br>加高的月台可以遠眺太平洋，感受海天一色的景致，<br>其月台更是橫跨基隆市與新北市，也是全台唯一橫跨兩縣市的車站，<br>十分特別，在這裡可以一腳站在新北市，一腳站在基隆；<br>周邊鄰近海洋科學博物館、深澳漁港、潮境公園等著名景點，<br>鐵軌自行車另一頭深澳段則靠近深澳車站遺址、象鼻岩、深澳漁港，<br>也可延伸至瑞芳、九份等觀光景點。', 'P1011674.jpg', 'P1011676.jpg', 'P1011682.jpg', '2020-07-21 00:11:04', 0),
	(6, '天福宮', 'j_06.png', '位於新北市瑞芳區深澳之天福宮，又稱蕃仔澳 天福宮，<br>臨近象鼻岩 風景區，供奉天上聖母為主神，<br>在民國83年以前原是供奉福德正神為主神，<br>土地公廟於清朝時期即有，迄今已有一百多年之歷史，<br>原位於蕃仔澳 山下，以三塊石疊起供奉之田頭田尾土地公，<br>土地公神靈顯赫，香火鼎盛，為深澳地區居民之信仰中心。<br>該廟原為土地公廟，背海而建，<br>廟前被民宅包圍出入須從旁邊，也是全省罕見。', 'P1011595.jpg', 'P1011604.jpg', 'P1011609.jpg', '2020-07-21 00:11:59', 0);
/*!40000 ALTER TABLE `scenic_spot` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
